#include "RenderSystem.h"

//For rendering FBOs
float rectangleVertices[] =
{
	// Coords    // texCoords
	 1.0f, -1.0f,  1.0f, 0.0f,
	-1.0f, -1.0f,  0.0f, 0.0f,
	-1.0f,  1.0f,  0.0f, 1.0f,

	 1.0f,  1.0f,  1.0f, 1.0f,
	 1.0f, -1.0f,  1.0f, 0.0f,
	-1.0f,  1.0f,  0.0f, 1.0f
};

int attribs[] = { 2, 2 };
Mesh* utilMesh = nullptr;
ShaderPass* utilSp = nullptr;

void RenderSystem::start() {
	utilSp = new ShaderPass("src/Shaders/plainFBO.frag", "src/Shaders/plainFBO.vert");
	utilMesh = new Mesh(rectangleVertices, 6, sizeof(rectangleVertices), utilSp, 4, 2, attribs);
}

void RenderSystem::update() {
	this->draw();
}

void RenderSystem::fixedUpdate() {}

void RenderSystem::end() {
	this->clearCurrentScene();
}

void RenderSystem::draw() {

	// FILL ALL FBOS
	const std::vector<gameObject*>& gos = this->currentScene->getGameObjects();
	for (auto cam : this->currentScene->getCameras()) {
		if (cam->getComponent<Camera>()->postProcessing) {
			cam->getComponent<Camera>()->getFBO()->Bind();
			glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
			for (auto go : gos) {
				Mesh* ms = go->getComponent<Mesh>();
				if (ms == nullptr) continue;

				ShaderPass* sp = ms->getShaderPass();
				VAO* vao = ms->getVAO();
				if (vao == nullptr || sp == nullptr) {
					std::cerr << "ERROR :: NO VAO OR SHADERPASS, SKIPPING: " << go->name;
					continue;
				}

				sp->bind();
				vao->Bind();

				auto& textures = ms->getTextures();
				for (int i = 0; i < (int)textures.size(); i++) {
					textures[i]->bind(i);
					sp->setInt("tex" + std::to_string(i), i);
				}



				//Default behavior
				glm::mat4 model = glm::mat4(1);
				glm::mat4 view = glm::mat4(1.0f);
				glm::mat4 projection = glm::perspective(glm::radians(45.0f), 1920.0f / 1080.0f, 0.1f, 100.0f);
				glm::mat4 VP = projection * view;

				VP = cam->getComponent<Camera>()->getVPMatrix();

				Transform* ts = go->getComponent<Transform>();
				if (ts != nullptr) {
					model = ts->getModel();
				}
				else {
					std::cerr << "[RenderSystem] ERROR :: NO TRANSFORM COMPONENT FOUND WHEN ATTEMPTING TO DRAW GAMEOBEJCT: " << go->name << " USING DEFAULT BEHAVIOR;\n";
					model = glm::mat4(1);
				}

				sp->setFloat("time", glfwGetTime());
				sp->setVec3("mainCameraPos", currentScene->getMainCamera()->getComponent<Transform>()->getPosition());
				sp->setMatrix4("model", model);
				sp->setMatrix4("VP", VP);

				// if light set color uniform for shader
				Light* lightComp = go->getComponent<Light>();
				if (lightComp != nullptr)
				{
					sp->setVec3("color", lightComp->getColor());
				}

				// set light uniforms for shader, only supports up to 32 lights for now
				// not very efficient light management, but good enough for a simple engine and demo scene
				// if you want light in your shaders, make sure to follow the template light structure.

				std::vector<gameObject*> lights = currentScene->getLights();
				int count = std::min((int)lights.size(), 32);
				sp->setInt("lightCount", count);
				for (int i = 0; i < count; i++)
				{
					gameObject* go = lights[i];

					Light* light = go->getComponent<Light>();
					Transform* transform = go->getComponent<Transform>();

					if (!light || !transform) continue;

					std::string base = "lights[" + std::to_string(i) + "]";

					sp->setVec3(base + ".position", transform->getPosition());

					sp->setVec3(base + ".color", light->getColor());

					sp->setFloat(base + ".intensity", light->getIntensity());
				}


				ms->draw();

				sp->unbind();
				vao->Unbind();


			}
			cam->getComponent<Camera>()->getFBO()->Unbind();
		}
	}

	// DECIDE WHAT WE ARE RENDERING
	if (this->currentScene->getMainCamera()->getComponent<Camera>()->postProcessing) {
		
	}
	else {
		// Bind default framebuffer
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
		glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);

		Camera* mainCam = this->currentScene->getMainCamera()->getComponent<Camera>();

		utilSp->bind();

		VAO* vao = utilMesh->getVAO();
		vao->Bind();

		glDisable(GL_DEPTH_TEST);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, mainCam->getFBO()->getTexture()->ID);
		utilSp->setInt("screenTexture", 0);

		glDrawArrays(GL_TRIANGLES, 0, 6);

		glEnable(GL_DEPTH_TEST);
		utilSp->unbind();
		vao->Unbind();
	}

}

void RenderSystem::setCurrentScene(GameScene* scene) {
	this->currentScene = scene;
}

void RenderSystem::clearCurrentScene() {
	this->currentScene = nullptr;
}

