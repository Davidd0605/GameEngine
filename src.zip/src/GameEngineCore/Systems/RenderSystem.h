#ifndef RENDER_SYSTEM_H
#define RENDER_SYSTEM_H

#include "GameSystem.h"
#include "GameScene.h"
#include "GameObject.h"
#include "VAO.h"
#include "ShaderPass.h"
#include "Mesh.h"
#include <vector>
/// <summary>
/// System responsible for drawing all meshes in a game scene
/// </summary>
class RenderSystem : public GameSystem
{
public:
	void start() override;
	void update() override;
	void end() override;

	void setCurrentScene(GameScene* scene) override;
	void clearCurrentScene() override;
protected:
	using GameSystem::currentScene;
	void draw();
};
#endif

