#ifndef SCENE_H
#define SCENE_H
	
#include <string>
#include "Camera.h"
/// <summary>
/// Abstract class for the scene.
/// </summary>
class Scene {

	public:
		Scene(std::string name);
		Scene(std::string name, Camera* mainCamera);

		//Must be overriden
		void virtual update() = 0;
		void virtual start() = 0;
		void virtual end() = 0;

		std::string name;

		void setMainCamera(Camera* mainCamera);
		Camera* getMainCamera();
private:
	Camera* mainCamera;
};

#endif // !SCENE_H
