#ifndef SCENE_H
#define SCENE_H

#include <string>
#include <GLFW/glfw3.h>
#include "../Components/Camera.h"
#include "../GameObjects/GameObject.h"
#include <vector>

class Scene {
public:
    Scene(std::string name, GLFWwindow* window);
    Scene(std::string name, GLFWwindow* window, gameObject* mainCamera);

    void virtual update() = 0;
    void virtual start() = 0;
    void virtual end() = 0;
    void virtual fixedUpdate() = 0;

    std::string name;

    void setMainCamera(gameObject* mainCamera);
    gameObject* getMainCamera();
    std::vector<gameObject*> getCameras();
    std::vector<gameObject*> getLights();

    GLFWwindow* getWindow() { return this->window; }

protected:
    gameObject* mainCamera;
    std::vector<gameObject*> cameras;
    std::vector<gameObject*> lights;
    GLFWwindow* window = nullptr;
};

#endif