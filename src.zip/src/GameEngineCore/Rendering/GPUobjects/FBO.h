#ifndef FBO_H
#define FBO_H

#include "../Texture.h"
#include <GLFW/glfw3.h>
class FBO
{
public:
	GLuint ID;
	FBO();
	void Bind();
	void Unbind();
	void Delete();
	Texture* getTexture();

private:
	Texture* texture;

};

#endif

