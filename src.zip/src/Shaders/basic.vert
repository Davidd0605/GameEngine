#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aCol;
layout (location = 2) in vec2 aTexCoord;

uniform float time;
uniform mat4 model;
uniform mat4 VP;

out vec4 vertexColor;
out vec2 texCoord;

void main() {
    gl_Position = VP * model * vec4(aPos, 1.0);
    vertexColor = vec4(aCol, 1.0);
    texCoord = aTexCoord;
}